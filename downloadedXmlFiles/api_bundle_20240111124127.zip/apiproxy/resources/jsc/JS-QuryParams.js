var requestBody = JSON.parse(context.getVariable('request.content'));

const username = requestBody.username;
const password = requestBody.password;
const mobile = requestBody.mobile;
const message = requestBody.message;
const sendername = requestBody.sendername;


context.setVariable("final",`username=${username}&password=${password}&mobile=${mobile}&message=${message}&sendername=${sendername}`);